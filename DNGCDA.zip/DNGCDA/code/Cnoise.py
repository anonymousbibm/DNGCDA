import torch

def edge_dropout_blocks(adj: torch.Tensor, n_circ: int,
                        drop_prob_cc, drop_prob_dd, drop_cd):

    device = adj.device
    N = adj.size(0)
    n_dis = N - n_circ

    def tri_mask(sz, p):
        if p <= 0:
            return torch.ones(sz, sz, device=device)
        m = (torch.rand((sz, sz), device=device) > p).float()
        m = torch.triu(m, 1)
        return m + m.t() + torch.eye(sz, device=device)

    mask_cc = tri_mask(n_circ, drop_prob_cc)       # circ–circ
    mask_dd = tri_mask(n_dis,  drop_prob_dd)       # dis–dis
    mask_cd = torch.ones((n_circ, n_dis), device=device) if drop_cd<=0 \
              else (torch.rand((n_circ, n_dis), device=device) > drop_cd).float()

    top    = torch.cat([mask_cc,      mask_cd     ], dim=1)
    bottom = torch.cat([mask_cd.t(),  mask_dd     ], dim=1)
    mask   = torch.cat([top, bottom], dim=0)

    return adj * mask

def make_feat_noise_fn(noise_std: float):
    def _aug(X_emb: torch.Tensor) -> torch.Tensor:
        if noise_std <= 0:
            return X_emb
        # print(f"X_emb shape {X_emb.shape}")
        return X_emb + torch.randn_like(X_emb) * noise_std
    return _aug

def make_feat_mask_fn(mask_prob: float):
    def _aug(X_emb: torch.Tensor) -> torch.Tensor:
        if mask_prob <= 0:
            return X_emb
        mask = (torch.rand_like(X_emb) > mask_prob).float()
        return X_emb * mask
    return _aug

def compose_feat_aug(*aug_fns):
    def _aug(X_emb):
        for fn in aug_fns:
            if fn is not None:
                X_emb = fn(X_emb)
        return X_emb
    return _aug

def make_node_subset_feature_dropout_fn(mask_indices: torch.Tensor, feat_drop_prob: float):

    mask_indices = mask_indices.clone()

    def _aug(X_emb: torch.Tensor) -> torch.Tensor:
        if mask_indices.numel() == 0 or feat_drop_prob <= 0:
            return X_emb
        X = X_emb.clone()
        K = mask_indices.numel()
        D = X.size(1)
        keep = (torch.rand((K, D), device=X.device) > feat_drop_prob).float()
        X_sel = X[mask_indices] * keep
        X[mask_indices] = X_sel
        return X
    return _aug
