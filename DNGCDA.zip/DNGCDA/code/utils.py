import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score, average_precision_score, recall_score, \
    precision_score, roc_curve, precision_recall_curve
import os
import csv

def row_normalize_t(A, eps=1e-12):
    return A / A.sum(dim=1, keepdim=True).clamp_min(eps)

def sym_normalize_t(A, eps=1e-12):
    deg = A.sum(dim=1).clamp_min(eps)
    d_inv_sqrt = deg.pow(-0.5)
    return d_inv_sqrt.unsqueeze(1) * A * d_inv_sqrt.unsqueeze(0)

import numpy as np

def compute_metrics(probs, preds, labels):
    probs = probs.flatten()
    preds = preds.flatten()
    labels = labels.flatten()

    if len(set(labels)) < 2:
        print("Warning: Only one class present in y_true. Skipping AUC calculation.")
        return {
            "AUC": float('nan'),
            "AUPR": float('nan'),
            "Accuracy": accuracy_score(labels, preds),
            "F1": f1_score(labels, preds, zero_division=1),
            "Recall": recall_score(labels, preds, zero_division=1),
            "Precision": precision_score(labels, preds, zero_division=1)
        }

    return {
        "AUC": roc_auc_score(labels, probs),
        "AUPR": average_precision_score(labels, probs),
        "Accuracy": accuracy_score(labels, preds),
        "F1": f1_score(labels, preds, zero_division=1),
        "Recall": recall_score(labels, preds, zero_division=1),
        "Precision": precision_score(labels, preds, zero_division=1)
    }

def save_to_csv(data, filename="test_Aevaling_metrics.csv"):
    file_exists = os.path.isfile(filename)
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)

        if not file_exists:
            writer.writerow(['Fold', 'AUC', 'AUPR', 'Accuracy', 'F1', 'Recall', 'Precision'])  # 表头
        writer.writerow(data)


def save_roc_pr_to_csv(all_folds_roc, pr_data, recall_data, aupr_folds, filename_suffix=""):
    # ===== ROC =====
    roc_records = []
    for fold, (fpr, tpr, auc) in enumerate(all_folds_roc, start=1):
        for f, t in zip(fpr, tpr):
            roc_records.append({'fold': fold, 'fpr': f, 'tpr': t, 'auc': auc})
    roc_df = pd.DataFrame(roc_records)
    roc_df.to_csv(f"roc_data_{filename_suffix}.csv", index=False)

    # ===== PR  =====
    pr_records = []
    for fold, (precision_arr, recall_arr, aupr) in enumerate(zip(pr_data, recall_data, aupr_folds), start=1):
        prec = np.ravel(precision_arr)
        rec  = np.ravel(recall_arr)

        sort_idx = np.argsort(rec)
        rec = rec[sort_idx]
        prec = prec[sort_idx]

        for p, r in zip(prec, rec):
            pr_records.append({
                'fold': fold,
                'recall': float(r),
                'precision': float(p),
                'aupr': float(aupr)
            })

    pr_df = pd.DataFrame(pr_records)
    pr_df.to_csv(f"pr_data_{filename_suffix}.csv", index=False)
