import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import (roc_auc_score, matthews_corrcoef, accuracy_score,
                             recall_score, precision_score, average_precision_score)
import pandas as pd
from transEn2 import *
from CotransGNN import *
import argparse
from Cnoise import *
from utils import *
from typing import Any, Callable, Dict, Optional
from dataclasses import dataclass
from hyperparam import DEFAULT_DATASET, DEVICE, FOLD_DATA_ROOT, HYPERPARAMS, K_FOLDS, SEED

import random
def set_seed(seed=3407):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

@dataclass
class HPConfig:

    lr: float = 1e-4
    emb_dim: int = 128
    pos_emb_dim: int = 4
    num_heads: int = 8
    num_layers: int = 8
    topk: int = 10
    lambda_contrast: float = 0.1
    edge_drop_cc: float = 0.05
    edge_drop_dd: float = 0.1
    noise_std: float = 0.01
    mask_prob: float = 0.04
    missing_ratio: float = 0.3
    feat_drop_prob: float = 0.4
    threshold: float = 0.6
    dropout: float = 0.1
    epochs: int = 400
    batch_size: int = 128
    hard_ratio: float = 0.9
    tau: float = 0.2


class PairTableDataset(Dataset):
    def __init__(self, pairs_df: pd.DataFrame):
        self.rna_idx = pairs_df["rna_idx"].to_numpy(dtype=np.int64)
        self.disease_idx = pairs_df["disease_idx"].to_numpy(dtype=np.int64)
        self.labels = pairs_df["label"].to_numpy(dtype=np.float32)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        label = torch.tensor(self.labels[idx], dtype=torch.float32)
        return (int(self.rna_idx[idx]), int(self.disease_idx[idx])), label


def build_heterograph(circrna_disease_matrix, circSimi, disSimi, threshold):
    matAdj_dis = np.where(disSimi > threshold, 1, 0)
    matAdj_circ = np.where(circSimi > 0.3, 1, 0)

    h_adjmat_1 = np.hstack((matAdj_circ, circrna_disease_matrix))
    h_adjmat_2 = np.hstack((circrna_disease_matrix.transpose(), matAdj_dis))
    Heterogeneous = np.vstack((h_adjmat_1, h_adjmat_2))

    return Heterogeneous

class PairProjection(torch.nn.Module):
    def __init__(self, in_dim, hidden, out_dim):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden),
            torch.nn.ReLU(inplace=True),
            torch.nn.Linear(hidden, out_dim)
        )
    def forward(self, x):
        z = self.net(x)
        return torch.nn.functional.normalize(z, dim=-1)


def normalize_adj_symmetric(adj: np.ndarray, add_self_loop: bool = True, eps: float = 1e-8):
    adj = adj.astype(np.float32).copy()

    if add_self_loop:
        adj = adj + np.eye(adj.shape[0], dtype=np.float32)

    degree = np.sum(adj, axis=1)
    degree_inv_sqrt = np.power(degree + eps, -0.5)
    degree_inv_sqrt[np.isinf(degree_inv_sqrt)] = 0.0

    D_inv_sqrt = np.diag(degree_inv_sqrt)
    adj_norm = D_inv_sqrt @ adj @ D_inv_sqrt
    return adj_norm.astype(np.float32)


def _fold_subdir_path(fold_dir: str, fold: int) -> str:
    return os.path.join(fold_dir, f"fold_{fold}")


def _fold_matrix_path(fold_dir: str, fold: int, filename: str) -> str:
    return os.path.join(_fold_subdir_path(fold_dir, fold), filename)


def complete_fold_files_exist(fold_dir: str, k_folds: int) -> bool:
    required_names = [
        "train_pairs.csv",
        "test_pairs.csv",
        "train_association_matrix.csv",
        "circRNA_similarity.csv",
        "disease_similarity.csv",
    ]
    for fold in range(1, k_folds + 1):
        for filename in required_names:
            if not os.path.exists(_fold_matrix_path(fold_dir, fold, filename)):
                return False
    return True


def _read_pair_file(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = ["rna_idx", "disease_idx", "label"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing columns {missing} in {path}")
    for col in required:
        df[col] = df[col].astype(int)
    return df


def load_fold_data(fold_dir: str, fold: int) -> Dict[str, Any]:
    fold_subdir = _fold_subdir_path(fold_dir, fold)
    train_pairs_file = os.path.join(fold_subdir, "train_pairs.csv")
    test_pairs_file = os.path.join(fold_subdir, "test_pairs.csv")
    assoc_file = os.path.join(fold_subdir, "train_association_matrix.csv")
    rna_file = os.path.join(fold_subdir, "circRNA_similarity.csv")
    disease_file = os.path.join(fold_subdir, "disease_similarity.csv")

    required_files = [train_pairs_file, test_pairs_file, assoc_file, rna_file, disease_file]
    missing_files = [path for path in required_files if not os.path.exists(path)]
    if missing_files:
        raise FileNotFoundError(f"Missing fold data files: {missing_files}")

    return {
        "train_pairs": _read_pair_file(train_pairs_file),
        "test_pairs": _read_pair_file(test_pairs_file),
        "association": pd.read_csv(assoc_file, index_col=0).values.astype(np.float32),
        "rna_features": pd.read_csv(rna_file, index_col=0).values.astype(np.float32),
        "disease_features": pd.read_csv(disease_file, index_col=0).values.astype(np.float32),
    }


def cross_validation_transgnn_cfg(
    k_folds: int,
    device,
    hp: HPConfig,
    build_model_fn: Optional[Callable[..., Any]] = None,
    fold_dir: str = "fold_data",
) -> Dict[str, Any]:
    auc_list, aupr_list, acc_list, f1_list, recall_list, prec_list, mcc_list = [], [], [], [], [], [], []


    for fold in range(k_folds):
        fold_no = fold + 1
        fold_data = load_fold_data(fold_dir, fold_no)
        train_df = fold_data["train_pairs"]
        test_df = fold_data["test_pairs"]
        print(f"\n=== Fold {fold_no}/{k_folds} ===")
        print(
            f"[Fold Data] Loaded fold {fold_no}: "
            f"train={len(train_df)}, test={len(test_df)}"
        )

        val_labels = test_df["label"].to_numpy(dtype=np.int64)

        val_pos_idx = np.where(val_labels == 1)[0]
        val_neg_idx = np.where(val_labels == 0)[0]

        num_val_pos = len(val_pos_idx)
        num_val_neg_sample = min(len(val_neg_idx), num_val_pos)
        rng = np.random.default_rng(3407 + fold)
        sampled_val_neg_idx = rng.choice(val_neg_idx, size=num_val_neg_sample, replace=False)

        val_idx_sampled = np.concatenate([val_pos_idx, sampled_val_neg_idx])
        rng.shuffle(val_idx_sampled)

        sampled_test_df = test_df.iloc[val_idx_sampled].reset_index(drop=True)
        val_loader = DataLoader(PairTableDataset(sampled_test_df), batch_size=hp.batch_size, shuffle=False)

        train_pairs = list(zip(
            train_df["rna_idx"].to_numpy(dtype=np.int64),
            train_df["disease_idx"].to_numpy(dtype=np.int64)
        ))
        train_rna_idx = sorted({i for i, _ in train_pairs})
        train_disease_idx = sorted({j for _, j in train_pairs})
        rna_id_map = {g: i for i, g in enumerate(train_rna_idx)}
        dis_id_map = {g: i for i, g in enumerate(train_disease_idx)}
        train_label_array = train_df["label"].to_numpy(dtype=np.float32)
        train_labels_full = torch.tensor(train_label_array, dtype=torch.float32, device=device)

        train_rna_full = torch.tensor(
            [rna_id_map[i] for i, _ in train_pairs],
            dtype=torch.long,
            device=device
        )
        train_dis_full = torch.tensor(
            [dis_id_map[j] for _, j in train_pairs],
            dtype=torch.long,
            device=device
        )
        train_pos_idx = torch.where(train_labels_full == 1)[0]
        train_neg_idx = torch.where(train_labels_full == 0)[0]

        def to_local_idx(global_idx_tensor, id_map):
            g = global_idx_tensor.detach().cpu().tolist()
            l = [id_map[int(x)] for x in g]
            return torch.tensor(l, device=global_idx_tensor.device, dtype=torch.long)

        missing_eval_pairs = [
            (int(r), int(d))
            for r, d in zip(sampled_test_df["rna_idx"], sampled_test_df["disease_idx"])
            if int(r) not in rna_id_map or int(d) not in dis_id_map
        ]
        if missing_eval_pairs:
            raise ValueError(
                "Current fold contains test pairs whose nodes do not appear in the training fold; "
                f"this training code does not support cold-start evaluation. Examples: {missing_eval_pairs[:5]}"
            )

        val_pos_pairs = list(zip(
            test_df.loc[test_df["label"] == 1, "rna_idx"].to_numpy(dtype=np.int64),
            test_df.loc[test_df["label"] == 1, "disease_idx"].to_numpy(dtype=np.int64)
        ))
        rel_matrix = fold_data["association"].copy().astype(np.float32)
        for rna_g, dis_g in val_pos_pairs:
            rel_matrix[rna_g, dis_g] = 0.0
        assoc_sub_train = rel_matrix[np.ix_(train_rna_idx, train_disease_idx)].copy().astype(np.float32)

        train_rna_features     = fold_data["rna_features"][train_rna_idx]
        train_disease_features = fold_data["disease_features"][train_disease_idx]

        hetero_adj_train = build_heterograph(
            assoc_sub_train,
            train_rna_features,
            train_disease_features,
            threshold=hp.threshold
        )

        "检查测试集正边是否仍残留在训练图（双向检查）"
        n_rna = len(train_rna_idx)
        val_pos_edges_in_train = []
        count_val_pos_in_train = 0

        for rna_g, dis_g in val_pos_pairs:
            if rna_g not in rna_id_map or dis_g not in dis_id_map:
                continue

            r_idx = rna_id_map[rna_g]
            d_idx = dis_id_map[dis_g]

            forward_exists = hetero_adj_train[r_idx, n_rna + d_idx] > 0
            backward_exists = hetero_adj_train[n_rna + d_idx, r_idx] > 0

            if forward_exists or backward_exists:
                count_val_pos_in_train += 1
                val_pos_edges_in_train.append({
                    "pair": (rna_g, dis_g),
                    "forward": int(forward_exists),
                    "backward": int(backward_exists)
                })
        print(f"[DEBUG] 测试集正边在训练图中仍残留的数量: {count_val_pos_in_train} / {len(val_pos_pairs)}")
        print("[DEBUG] 仍残留的测试集正边(含方向状态):", val_pos_edges_in_train)

        hetero_adj_train_norm = normalize_adj_symmetric(hetero_adj_train, add_self_loop=True)
        hetero_adj_tensor_train = torch.tensor(hetero_adj_train_norm, dtype=torch.float32).to(device)

        pos_emb_dim = hp.pos_emb_dim
        encoding_train = TransEncoding(hetero_adj_train, device=device, pos_emb_dim=pos_emb_dim)

        with torch.no_grad():
            _ = encoding_train.get_full_encoding()
    
        def _default_build_model():
            return TransGNN(
                num_rna=len(train_rna_idx),
                num_disease=len(train_disease_idx),
                encoding=encoding_train,
                emb_dim=hp.emb_dim,
                pos_emb_dim= hp.pos_emb_dim,
                num_heads=hp.num_heads,
                dropout=hp.dropout,
                num_layers=hp.num_layers,
                topk=hp.topk
            )

        model = (build_model_fn or _default_build_model)().to(device)

        enc_params = []
        enc_params += list(encoding_train.pr_mlp.parameters())
        enc_params += list(encoding_train.deg_mlp.parameters())

        for p in enc_params:
            p.requires_grad = True
        
        assert model.encoding.N == hetero_adj_tensor_train.shape[0]

        N = hetero_adj_tensor_train.shape[0]
        num_missing = int(round(N * hp.missing_ratio))
        g = torch.Generator(device="cpu")
        g.manual_seed(3407 + fold)
        masked_nodes = torch.randperm(N, generator=g, device="cpu")[:num_missing].to(device)

        feat_aug_partial = make_node_subset_feature_dropout_fn(masked_nodes, hp.feat_drop_prob)

        pair_proj = PairProjection(in_dim=model.layer_d_models[-1], hidden=128, out_dim=128).to(device)

        optimizer = torch.optim.Adam(list(model.parameters()) + list(pair_proj.parameters()) + enc_params,lr=hp.lr)

        criterion = torch.nn.BCEWithLogitsLoss(reduction='mean')

        for epoch in range(hp.epochs):
            model.train()
            total_loss = 0.0
            pair_proj.train()

            n_circ_fold = len(train_rna_idx)
            adj_view_a = edge_dropout_blocks(hetero_adj_tensor_train, n_circ=n_circ_fold,
                                             drop_prob_cc=hp.edge_drop_cc, drop_prob_dd=hp.edge_drop_dd, drop_cd=0.0)
            adj_view_b = edge_dropout_blocks(hetero_adj_tensor_train, n_circ=n_circ_fold,
                                             drop_prob_cc=hp.edge_drop_cc, drop_prob_dd=hp.edge_drop_dd, drop_cd=0.0)

            feat_aug_a = compose_feat_aug(feat_aug_partial, make_feat_noise_fn(noise_std=hp.noise_std))
            feat_aug_b = compose_feat_aug(feat_aug_partial, make_feat_mask_fn(mask_prob=hp.mask_prob))

            _, rna_emb_a, disease_emb_a = model(adj_view_a, feat_aug=feat_aug_a)
            _, rna_emb_b, disease_emb_b = model(adj_view_b, feat_aug=feat_aug_b)

            num_pos = train_pos_idx.numel()
            num_neg_sample = min(train_neg_idx.numel(), num_pos)

            hard_ratio = hp.hard_ratio
            num_hard = int(num_neg_sample * hard_ratio)
            num_rand = num_neg_sample - num_hard
            with torch.no_grad():
                neg_rna = train_rna_full[train_neg_idx]
                neg_dis = train_dis_full[train_neg_idx]

                neg_rna_emb_a = torch.nn.functional.normalize(rna_emb_a[neg_rna], p=2, dim=1)
                neg_dis_emb_a = torch.nn.functional.normalize(disease_emb_a[neg_dis], p=2, dim=1)
                neg_scores_a = (neg_rna_emb_a * neg_dis_emb_a).sum(dim=1)

                neg_rna_emb_b = torch.nn.functional.normalize(rna_emb_b[neg_rna], p=2, dim=1)
                neg_dis_emb_b = torch.nn.functional.normalize(disease_emb_b[neg_dis], p=2, dim=1)
                neg_scores_b = (neg_rna_emb_b * neg_dis_emb_b).sum(dim=1)

                neg_scores = 0.5 * neg_scores_a + 0.5 * neg_scores_b

                order = torch.argsort(neg_scores, descending=True)
                start = int(0.1 * order.numel())
                end = int(0.4 * order.numel())
                semi_hard_pool = train_neg_idx[order[start:end]]

                perm_hard = torch.randperm(semi_hard_pool.numel(), device=device)[:num_hard]
                hard_neg_idx = semi_hard_pool[perm_hard]

                perm_rand = torch.randperm(train_neg_idx.numel(), device=device)[:num_rand]
                rand_neg_idx = train_neg_idx[perm_rand]

            sampled_neg_idx = torch.cat([hard_neg_idx, rand_neg_idx], dim=0)

            sampled_idx = torch.cat([train_pos_idx, sampled_neg_idx], dim=0)
            shuffle_idx = sampled_idx[torch.randperm(sampled_idx.numel(), device=device)]
            sampled_rna = train_rna_full[shuffle_idx]
            sampled_dis = train_dis_full[shuffle_idx]
            sampled_labels = train_labels_full[shuffle_idx]

            rna_batch_a = torch.nn.functional.normalize(rna_emb_a[sampled_rna], p=2, dim=1)
            dis_batch_a = torch.nn.functional.normalize(disease_emb_a[sampled_dis], p=2, dim=1)
            scores_a = (rna_batch_a * dis_batch_a).sum(dim=1)
            bce_loss_a = criterion(scores_a.view(-1), sampled_labels.view(-1))
            rna_batch_b = torch.nn.functional.normalize(rna_emb_b[sampled_rna], p=2, dim=1)
            dis_batch_b = torch.nn.functional.normalize(disease_emb_b[sampled_dis], p=2, dim=1)
            scores_b = (rna_batch_b * dis_batch_b).sum(dim=1)
            bce_loss_b = criterion(scores_b.view(-1), sampled_labels.view(-1))

            bce_loss = 0.5 * (bce_loss_a + bce_loss_b)

            if hp.lambda_contrast > 0:
                cl_loss = pair_level_contrastive_loss(
                    rna_emb_a, disease_emb_a,
                    rna_emb_b, disease_emb_b,
                    sampled_rna, sampled_dis,
                    proj_head=pair_proj,
                    tau=hp.tau
                )

            else:
                cl_loss = torch.tensor(0.0, device=device)

            loss = bce_loss + hp.lambda_contrast * cl_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss = loss.item()

            if (epoch+1) % 100 ==0:
                print(f"Fold {fold + 1} Epoch {epoch + 1}/{hp.epochs} | Loss {total_loss:.4f} | bce_loss {bce_loss:.4f} | cl_loss {cl_loss:.4f}")

        model.eval()
        all_probs, all_labels = [], []
        with torch.no_grad():
            _, rna_emb_eval, disease_emb_eval = model(hetero_adj_tensor_train, feat_aug=None)
            for (rna_idx, disease_idx), batch_label in val_loader:
                rna_idx = rna_idx.to(device); disease_idx = disease_idx.to(device)
                local_rna = to_local_idx(rna_idx, rna_id_map)
                local_dis = to_local_idx(disease_idx, dis_id_map)

                rna_batch = torch.nn.functional.normalize(rna_emb_eval[local_rna], p=2, dim=1)
                dis_batch = torch.nn.functional.normalize(disease_emb_eval[local_dis], p=2, dim=1)
                scores = (rna_batch * dis_batch).sum(dim=1)
                probs = torch.sigmoid(scores).detach().cpu().numpy()
                all_probs.append(probs); all_labels.append(batch_label.numpy())

        all_probs = np.concatenate(all_probs); all_labels = np.concatenate(all_labels)
        all_preds = (all_probs >= 0.45).astype(int)

        auc = roc_auc_score(all_labels, all_probs)
        aupr = average_precision_score(all_labels, all_probs)
        acc = accuracy_score(all_labels, all_preds)
        rec = recall_score(all_labels, all_preds)
        prec = precision_score(all_labels, all_preds)
        mcc = matthews_corrcoef(all_labels, all_preds)
        eps = 1e-8
        best_f1 = 2 * prec * rec / (prec + rec + eps)
        metrics = compute_metrics(all_probs, all_preds, all_labels)

        f1_list.append(best_f1);auc_list.append(auc); aupr_list.append(aupr); acc_list.append(acc)
        recall_list.append(rec); prec_list.append(prec); mcc_list.append(mcc)

        save_to_csv([fold + 1, auc, metrics["AUPR"], metrics["Accuracy"], metrics["F1"], metrics["Recall"],
                     metrics["Precision"]])

        print(
            f"Fold {fold + 1}, AUC: {auc:.4f}, AUPR: {aupr:.4f}, Acc: {acc:.4f}, F1: {best_f1:.4f}, "
            f"Recall: {rec:.4f}, Precision: {prec:.4f}, MCC: {mcc:.4f}")


    return {
        "AUC_mean": np.mean(auc_list),
        "AUPR_mean": np.mean(aupr_list),
        "F1_mean": np.mean(f1_list),
        "ACC_mean": np.mean(acc_list),
        "REC_mean": np.mean(recall_list),
        "PREC_mean": np.mean(prec_list),
        "MCC_mean": np.mean(mcc_list),

        "AUC_list": auc_list,
        "AUPR_list": aupr_list,
        "F1_list": f1_list,
        "ACC_list": acc_list,
        "REC_list": recall_list,
        "PREC_list": prec_list,
        "MCC_list": mcc_list
    }


def run_experiment(dataset_name: str = DEFAULT_DATASET) -> Dict[str, Any]:
    set_seed(SEED)
    fold_dir = os.path.join(FOLD_DATA_ROOT, dataset_name)
    if not complete_fold_files_exist(fold_dir, K_FOLDS):
        raise FileNotFoundError(
            f"Complete fold files were not found in {fold_dir}. "
            "Expected fold_1..fold_5 directories with train_pairs.csv, test_pairs.csv, "
            "train_association_matrix.csv, circRNA_similarity.csv, and disease_similarity.csv."
        )

    device = torch.device(DEVICE)
    hp = HPConfig(**HYPERPARAMS)

    print(f"Dataset: {dataset_name}")
    print(f"Device: {device}")
    print(f"Fold data directory: {fold_dir}")
    print("Hyperparameters:")
    for key, value in HYPERPARAMS.items():
        print(f"  {key}: {value}")

    result = cross_validation_transgnn_cfg(
        k_folds=K_FOLDS,
        device=device,
        hp=hp,
        fold_dir=fold_dir,
    )

    print("\n=== Five-fold cross-validation mean ===")
    print(
        f"{result['AUC_mean']:.4f},"
        f"{result['AUPR_mean']:.4f},"
        f"{result['F1_mean']:.4f},"
        f"{result['ACC_mean']:.4f},"
        f"{result['REC_mean']:.4f},"
        f"{result['PREC_mean']:.4f},"
        f"{result['MCC_mean']:.4f}"
    )
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run TransGNN with fixed hyperparameters.")
    parser.add_argument("--dataset", default=DEFAULT_DATASET, help="Subdirectory name under fold_data.")
    args = parser.parse_args()
    run_experiment(args.dataset)
