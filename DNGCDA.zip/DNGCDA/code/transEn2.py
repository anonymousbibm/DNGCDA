import torch
import numpy as np
import networkx as nx
import torch.nn as nn
import torch.nn.functional as F
import scipy.sparse
from typing import Optional, Tuple, List

try:
    import scipy.sparse as sp
    from scipy.sparse.csgraph import shortest_path as sp_shortest_path
    from scipy.sparse.linalg import eigsh
    SCIPY = True
except Exception:
    SCIPY = False

class AdaptiveWeighting(nn.Module):
    def __init__(self, input_dim, hidden_dim=64):
        super(AdaptiveWeighting, self).__init__()

        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, anchor_pe, laplacian_pe):
        combined_input = torch.cat([anchor_pe, laplacian_pe], dim=-1)
        weight = self.mlp(combined_input)
        return weight

class TransEncoding:
    def __init__(self, adj_matrix, device, pos_emb_dim):

        self.adj_matrix = adj_matrix
        self.N = adj_matrix.shape[0]
        self.pos_emb_dim = pos_emb_dim
        self.device = torch.device("cpu")
        # self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")

        if not scipy.sparse.issparse(adj_matrix):
            adj_matrix = scipy.sparse.csr_matrix(adj_matrix)
        self.nxG = nx.from_scipy_sparse_array(adj_matrix)

        if not isinstance(adj_matrix, nx.Graph):
            self.nxG = nx.from_scipy_sparse_array(adj_matrix)
        else:
            self.nxG = adj_matrix

        self.pr_mlp   = nn.Sequential(nn.Linear(1, pos_emb_dim), nn.ReLU())
        self.deg_mlp  = nn.Sequential(nn.Linear(1, pos_emb_dim), nn.ReLU())
        self.mean_mlp = nn.Sequential(nn.Linear(1, pos_emb_dim), nn.ReLU())
        self.max_mlp  = nn.Sequential(nn.Linear(1, pos_emb_dim), nn.ReLU())

        self.anchor_mlp  = nn.Sequential(nn.Linear(1, pos_emb_dim*2), nn.ReLU())
        self.pe_global = nn.Sequential(nn.Linear(1, pos_emb_dim*2), nn.ReLU())

        self.pe_rna = nn.Sequential(nn.Linear(1, pos_emb_dim), nn.ReLU())
        self.pe_dis = nn.Sequential(nn.Linear(1, pos_emb_dim), nn.ReLU())

        self.combined_pe_weight = nn.Parameter(torch.ones(1))

        self.adaptive_weighting = AdaptiveWeighting(input_dim=self.pos_emb_dim * 2, hidden_dim=64).to(device)


    def get_pagerank(self, alpha=0.7):
        pr = nx.pagerank(self.nxG, alpha=alpha)
        pr_vec = np.array([pr[i] for i in range(self.N)]).reshape(-1, 1)
        pr_vec = torch.from_numpy(pr_vec).float().to(next(self.pr_mlp.parameters()).device)
        return self.pr_mlp(pr_vec).to(self.device)  # [N, pos_emb_dim]

    def get_degree(self):
        deg = np.array([self.nxG.degree(i) for i in range(self.N)]).reshape(-1, 1)
        deg_norm = (deg - deg.min()) / (deg.max() - deg.min() + 1e-6)
        deg_norm = torch.from_numpy(deg_norm).float().to(next(self.deg_mlp.parameters()).device)
        return self.deg_mlp(deg_norm).to(self.device)   # [N, pos_emb_dim]

    def get_full_encoding(self):
        pagerank = self.get_pagerank()
        degree = self.get_degree()
        out = torch.cat([pagerank, degree], dim=1)

        return out

    def dynamic_attention_sampling(self, embeddings, topk, sim_type="cosine"):
        N = embeddings.size(0)
        embeddings = embeddings.to(self.device)
        neighbors_idx = []
        if sim_type == "cosine":
            normed_emb = embeddings / (embeddings.norm(dim=1, keepdim=True) + 1e-8)
        else:
            normed_emb = embeddings
        sim_matrix = torch.mm(normed_emb, normed_emb.t())
        for i in range(N):
            sim_row = sim_matrix[i]
            sim_row[i] = -float('inf')
            topk_idx = torch.topk(sim_row, topk).indices
            neighbors_idx.append(topk_idx)
        return torch.stack(neighbors_idx, dim=0)


class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, num_heads, d_ff=None, dropout=0.2, activation="relu"):
        super(TransformerEncoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.attention = nn.MultiheadAttention(d_model, num_heads, dropout=dropout, batch_first=True)
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = getattr(F, activation)

    def forward(self, x, attn_mask=None):
        attn_output, _ = self.attention(x, x, x, key_padding_mask=attn_mask)
        x = x + self.dropout(attn_output)
        y = self.norm1(x)
        y = self.dropout(self.activation(self.linear1(y)))
        y = self.dropout(self.linear2(y))
        return self.norm2(x + y)
