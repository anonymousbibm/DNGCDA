import torch
import torch.nn as nn
from transEn2 import *

class TransGNN(nn.Module):
    def __init__(self, num_rna, num_disease, encoding,
                 emb_dim, pos_emb_dim, num_heads,
                 dropout, num_layers, topk):
        super(TransGNN, self).__init__()
        self.num_rna = num_rna
        self.num_disease = num_disease
        self.emb_dim = emb_dim
        self.pos_emb_dim = pos_emb_dim
        self.pos_feat_dim = 2*pos_emb_dim
        self.topk = topk
        self.encoding = encoding
        self.dropout = nn.Dropout(dropout)

        with torch.no_grad():
            pos = self.encoding.get_full_encoding()              # [N, n*pos_emb_dim]
        self.register_buffer("pos_encoding", pos, persistent=False)

        self.rna_embedding = nn.Parameter(nn.init.xavier_uniform_(torch.empty(num_rna, emb_dim)))
        self.disease_embedding = nn.Parameter(nn.init.xavier_uniform_(torch.empty(num_disease, emb_dim)))

        def make_divisible(c, divisor):
            return c if c % divisor == 0 else ((c // divisor) + 1) * divisor

        input_dims = [emb_dim + self.pos_feat_dim]
        for _ in range(num_layers):
            input_dims.append(input_dims[-1] + self.pos_feat_dim)

        self.gnn_layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(input_dims[i], input_dims[i + 1] - self.pos_feat_dim),
                nn.GELU(),
                nn.LayerNorm(input_dims[i + 1] - self.pos_feat_dim),
                nn.Dropout(dropout),
                nn.Linear(input_dims[i + 1] - self.pos_feat_dim, input_dims[i + 1] - self.pos_feat_dim)
            )
            for i in range(num_layers)
        ])
        self.gnn_res_proj = nn.ModuleList([
            nn.Identity() if input_dims[i] == (input_dims[i + 1] - self.pos_feat_dim)
            else nn.Linear(input_dims[i], input_dims[i + 1] - self.pos_feat_dim)
            for i in range(num_layers)
        ])

        self.layer_d_models = [make_divisible(input_dims[i + 1], num_heads) for i in range(num_layers)]

        self.pre_attn_proj = nn.ModuleList([
            nn.Identity() if input_dims[i + 1] == self.layer_d_models[i]
            else nn.Linear(input_dims[i + 1], self.layer_d_models[i])
            for i in range(num_layers)
        ])

        self.rna_transformer = nn.ModuleList([
            TransformerEncoderLayer(d_model=self.layer_d_models[i], num_heads=num_heads, dropout=dropout)
            for i in range(num_layers)
        ])
        self.disease_transformer = nn.ModuleList([
            TransformerEncoderLayer(d_model=self.layer_d_models[i], num_heads=num_heads, dropout=dropout)
            for i in range(num_layers)
        ])

    def gnn_message_passing(self, adj_norm, embeds):
        return torch.mm(adj_norm, embeds)

    def graph_edge_sampling(self, adj, topk):
        N = adj.size(0)
        neighbors_idx = []
        for i in range(N):
            nbr = torch.where(adj[i] > 0)[0]
            nbr = nbr[nbr != i]
            if nbr.numel() == 0:
                nbr = torch.full((topk,), i, device=adj.device, dtype=torch.long)
            elif nbr.numel() >= topk:
                nbr = nbr[:topk]
            else:
                pad = nbr[-1].repeat(topk - nbr.numel())
                nbr = torch.cat([nbr, pad], dim=0)
            neighbors_idx.append(nbr)
        return torch.stack(neighbors_idx, dim=0)


    def forward(self, adj, feat_aug=None):
        pos_encoding = self.pos_encoding.to(adj.device)

        X_emb = torch.cat([self.rna_embedding, self.disease_embedding], dim=0)

        if feat_aug is not None:
            X_emb = feat_aug(X_emb)

        X = torch.cat([X_emb, pos_encoding], dim=1)

        rna_slice = slice(0, self.num_rna)
        disease_slice = slice(self.num_rna, self.num_rna + self.num_disease)

        for l in range(len(self.gnn_layers)):

            X_msg = self.gnn_message_passing(adj, X)

            X_hidden = self.gnn_layers[l](X_msg) + self.gnn_res_proj[l](X)

            X_cat = torch.cat([X_hidden, pos_encoding], dim=1)
            X_proj = self.pre_attn_proj[l](X_cat)

            neighbors_idx = self.encoding.dynamic_attention_sampling(X_proj, topk=self.topk)

            neigh = X_proj[neighbors_idx]
            x_input = torch.cat([X_proj.unsqueeze(1), neigh], dim=1)

            X_rna = x_input[rna_slice]
            X_dis = x_input[disease_slice]

            X_rna = self.rna_transformer[l](X_rna)[:, 0, :]
            X_dis = self.disease_transformer[l](X_dis)[:, 0, :]

            X = torch.cat([X_rna, X_dis], dim=0)

        out_emb = X
        rna_emb = out_emb[rna_slice]
        disease_emb = out_emb[disease_slice]
        return out_emb, rna_emb, disease_emb


def contrastive_loss_ntxent(z_a: torch.Tensor, z_b: torch.Tensor, tau):
    sim = (z_a @ z_b.t()) / tau
    logp_a2b = torch.nn.functional.log_softmax(sim, dim=1)
    logp_b2a = torch.nn.functional.log_softmax(sim.t(), dim=1)
    idx = torch.arange(z_a.size(0), device=z_a.device)
    loss = -(logp_a2b[idx, idx].mean() + logp_b2a[idx, idx].mean()) * 0.5
    return loss


def pair_level_contrastive_loss(rna_emb_a: torch.Tensor,
                                disease_emb_a: torch.Tensor,
                                rna_emb_b: torch.Tensor,
                                disease_emb_b: torch.Tensor,
                                rna_idx: torch.Tensor,
                                disease_idx: torch.Tensor,
                                proj_head: torch.nn.Module,
                                tau):
    rna_a = rna_emb_a[rna_idx]
    dis_a = disease_emb_a[disease_idx]
    rna_b = rna_emb_b[rna_idx]
    dis_b = disease_emb_b[disease_idx]

    pair_a = rna_a * dis_a
    pair_b = rna_b * dis_b
    z_a = proj_head(pair_a)
    z_b = proj_head(pair_b)

    return contrastive_loss_ntxent(z_a, z_b, tau=tau)
