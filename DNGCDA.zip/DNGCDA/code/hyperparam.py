import torch

K_FOLDS = 5
SEED = 3407
DEFAULT_DATASET = "circ2Disease"
FOLD_DATA_ROOT = "fold_data"
DEVICE = "cpu"
# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

HYPERPARAMS = {
    "lr": 1e-4,
    "emb_dim": 128,
    "pos_emb_dim": 4,
    "num_heads": 8,
    "num_layers": 8,
    "topk": 10,
    "lambda_contrast": 0.1,
    "edge_drop_cc": 0.05,
    "edge_drop_dd": 0.1,
    "noise_std": 0.01,
    "mask_prob": 0.04,
    "missing_ratio": 0.3,
    "feat_drop_prob": 0.4,
    "threshold": 0.6,
    "dropout": 0.1,
    "epochs": 400,
    "batch_size": 128,
    "hard_ratio": 0.9,
    "tau": 0.2,
}
