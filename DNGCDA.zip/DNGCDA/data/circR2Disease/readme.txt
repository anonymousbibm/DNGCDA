Number of unique circRNAs: 613
Number of unique diseases: 86
Number of associations: 659