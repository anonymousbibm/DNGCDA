Number of unique circRNAs: 632
Number of unique diseases: 89
Number of associations: 744