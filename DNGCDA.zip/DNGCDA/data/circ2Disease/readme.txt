circ2Disease4
Number of unique circRNAs: 249
Number of unique diseases: 54
Number of associations: 267

